#include<stdio.h>

int main()
{
  
  
  void fun1();
  fun1();
   printf("Hello world");

retrun 0;
}

void fun1()
{


}
