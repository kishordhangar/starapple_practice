//Header file
#include<stdio.h>

// entry point function
int main()
{


//print output on consol(terminal)
printf("Hello Welcome To Again C Programming Batch");


//return call to main function
    return 0;

}