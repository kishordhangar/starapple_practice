// How To print hellow world on consol

// header file

#include<stdio.h>

//entry point function

int main()
{

//use this function to show output on consol

printf("\n Hello world\n");

return 0;
}
