//To print the Division of two int values 
#include<stdio.h>
int main ()
{
  //a,b,c are the identifiers of int datataypes(that means local variable declaration)
int a=4;
int b= 6;
int c;
a/b= c;
printf("Division of two number's=%d",c);
return 0;
}