//Header file
#include<stdio.h>
int main()
{

    char print[]="Hello world";
    {

     printf("\n");

     printf(print);

     printf("\n\n");
    
    }


    return 0;
}