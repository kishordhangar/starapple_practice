// infinite for loop

#include<stdio.h>
int main()
{

    int i=1;
    for( ; ; i++)
    printf("%d",i);

    return 0;
}