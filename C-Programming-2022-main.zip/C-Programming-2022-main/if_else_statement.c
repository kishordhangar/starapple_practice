#include<stdio.h>

int main()
{

if(0)
{
printf("Condition is true....");


}
else
{


printf("Condition is false....");
}


retrun 0;
}
