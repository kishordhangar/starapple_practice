#include<stdio.h>

int main()

{

int a;
int b;

printf("enter first value is = \n");
scanf("%d",a);
printf("enter Second value is = \n");
scanf("%d",b);

if(a==b)

{ printf("\nBoth integer values are same"); }

else

{ 
printf("\nBoth integer values are different"); }

return 0;
}