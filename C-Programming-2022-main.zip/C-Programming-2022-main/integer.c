#include<stdio.h>
int main()
{
int a=10;

printf("c-program integer =%d",a);
    return 0;
}