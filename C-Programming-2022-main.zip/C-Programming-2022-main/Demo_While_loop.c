#include<stdio.h>

int main()
{
	// Local variable declaration
	int i = 5;


	while (--i)
	{
		printf("\n in While Loop");
		printf("\n i = %d", i);
	}

	return(0);
}