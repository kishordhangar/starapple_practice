#include<stdio.h>
int main()
{

printf("\n\nH\tello");
printf("\n\nHe\tllo");
printf("\n\nHel\tlo");
printf("\n\nHell\to\n\n");

    return 0;
}