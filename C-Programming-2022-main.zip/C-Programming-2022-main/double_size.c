//9. Print size of double

#include<Stdio.h>

int main()
{
    double d;

    printf("\n\nSize of double = %d\n\n",sizeof(d));

    return 0;
}