
//header file in c
#include<stdio.h>


//entry point function // it means the start of program
int main()
{
	
/*	// local varibale declaration
	
	int a=0;
	int b=0;
	
for(a=0,b=0; a<=10,b<=10; a++,b++)
{
	printf("\nhello world a  =%d",a);
	printf("\nhello world b =%d",b);
}	
*/

int i=0;
for(i=0; i<=10; i=i+2)
	

{
	printf("\nsecond program %d",i);
}
printf("\nsecond program J value");
int j=0;
for(j=0; j<=10; j=j+3)
{
		printf("\nsecond program %d",j);
}
printf("\nsecond program k value");
int k=0;
for(k=0; k<=10; k=k+4)
{
		printf("\nsecond program %d",k);
}
printf("\nsecond program L value");
int l=0;
for(l=0; l<=10; l=l+5)
{
		printf("\nsecond program %d",l);
}

return 0;
}