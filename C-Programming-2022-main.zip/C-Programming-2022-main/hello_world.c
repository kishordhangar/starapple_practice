

#include<stdio.h>
int main()
{

printf("\n\tc-programming batch November-2022\n\n");

    return 0;
}


