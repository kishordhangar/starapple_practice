//



// Header file

#include<stdio.h>

//entry point function

int main()
{

//use this function to show output on consol

printf("\n Hello world\n");

return 0;
}


/* 
	          

			   *OUTPUT*

Microsoft Windows [Version 10.0.22621.674]
(c) Microsoft Corporation. All rights reserved.

C:\Users\DELL>cd OneDrive

C:\Users\DELL\OneDrive>cd Desktop
 
C:\Users\DELL\OneDrive\Desktop>gcc l.c

C:\Users\DELL\OneDrive\Desktop>cd rahul_sir

C:\Users\DELL\OneDrive\Desktop\rahul_sir>gcc Hello_World.c

C:\Users\DELL\OneDrive\Desktop\rahul_sir>a.exe

 Hello world

C:\Users\DELL\OneDrive\Desktop\rahul_sir>*/



//
