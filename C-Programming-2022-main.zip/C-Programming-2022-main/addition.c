//To print the addition of two int values 
#include<stdio.h>
int main ()
{
int a=1;  //a,b,c are the identifiers of int datataypes(that means local variable declaration)
int b= 2;
int c;
a+b= c;
printf("addition of two number's=%d",c);
return 0;
}