//9. Print size of char

#include<Stdio.h>

int main()
{
    char;

    printf("\n\nSize of char = %d\n\n",char);

    return 0;
}