#include<Stdio.h>
int main()
{


    int a;
    int b;
    
    printf("1");
    scanf("%d",&a);

    
    printf("2");
    scanf("%d",&b);
    printf("=%d",a);

    printf("=%d",b);
    
}