#include<stdio.h>

int main()

{
    int a=10;
    a++;
    printf("value of a = %d",a);

// Condition false astani line print hotiye ka te vicharat hoto sir
return 0;
}
