
//10. Print default values of char,int,float,double variables
#include<stdio.h>
int main()
{
    {
      int a;
      printf("\n\nvalue of int=%d\n",a);
    }
        {
           float b;
           printf("\nvalue of float =%d\n",b);
        }
            {
              char c;
              printf("\nvalue of char=%c\n");
            }
                {
                  double d;
                  printf("\nvalue of double=%d\n\n",d);
                }
    return 0;
}