//9. Print size of Float

#include<Stdio.h>

int main()
{
    float f;

    printf("\n\nSize of float = %d",sizeof(f));

    return 0;
}