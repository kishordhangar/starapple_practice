//9. Print size of char

#include<Stdio.h>

int main()
{
    char c;

    printf("\n\nSize of char = %zu\n\n",sizeof(c));

    return 0;
}