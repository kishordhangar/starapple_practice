#include<stdio.h>

int main()
{
	// Variable Declarations
	int i;

	// code
	i = 5;
	do
	{
		printf("\n in do-while loop");
		i--;

	} while (i > 0);

	return(0);
}
