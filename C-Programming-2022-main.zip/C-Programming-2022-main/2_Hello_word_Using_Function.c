//Header file in c(its an compulsory)
#include<stdio.h>
//entry point function
int main()
{
    //call the function and  function declaration also
    void priyanka();
        priyanka();
    return 0;
}
void priyanka()
{
printf("\n\n\tThis is using function\n\n");
}
