#include<stdio.h>

int main()

{
    int a=10;
     a=a++;
    printf("value of a = %d",a);

return 0;
}
