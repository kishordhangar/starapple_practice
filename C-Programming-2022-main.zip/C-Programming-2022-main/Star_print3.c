#include<stdio.h>
int main()
{
    int i;

    for(i=1; i<=12; i++)
    {
        
        printf("**\n");
        
    }

    return 0;
}