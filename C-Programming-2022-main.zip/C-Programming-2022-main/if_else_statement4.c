#include<stdio.h>

int main()
{
if(3)

{ printf("\nCondition is true....\n"); }

else

{ printf("Condition is false...."); }
return 0;
}
