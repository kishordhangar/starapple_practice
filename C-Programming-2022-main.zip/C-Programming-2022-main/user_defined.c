


//Header file
#include<stdio.h>

//entry point function
int main()
{

    return 0;
}
//user defied function
void priyanka()
{
    
}