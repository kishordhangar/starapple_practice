#include<stdio.h>
int main()
{
    printf("\nFourth for loop\n");
    int i=1;
    for( ; i<=10;i++ )
   
    {
        
        printf("\n%d",i);  
    } 
    return 0;
}