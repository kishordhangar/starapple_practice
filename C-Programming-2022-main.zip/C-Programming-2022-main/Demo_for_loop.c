#include<stdio.h>

int main()
{
	// Local variable declaration
	int i;

	for (i = 5; i ;i--)
	{
		printf("\n In For loop");
		printf("\n i = %d", i);
	}
	
	return(0);
}