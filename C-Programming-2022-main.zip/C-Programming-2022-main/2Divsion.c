//6 Write a program for division of two numbers .

#include<stdio.h>
int main()
{
    float a=10;
    float b=3;

    float division=a/b;

    printf("\n\n Division of two numbers =%.2f\n\n",division);
    
    
    return 0;
}