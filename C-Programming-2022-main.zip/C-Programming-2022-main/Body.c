
// Body of c language coding
#include<stdio.h>
int main()
{


    return 0;
}