#include<stdio.h>

#define kishor main()//macro_substitution method
int kishor
{

    float float1 = 2.3;

printf("\n Stored Float Value = %.1f",float1);

    return 0;
}
