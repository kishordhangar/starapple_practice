//To print the arithmetic operations of two int values 
#include<stdio.h>
int main()
{
  //a,b are the identifiers of int datataypes(that means local variable declaration)
int a=3;
int b= 7;
printf("Substraction of two number's=%d\n",a-b);
printf("Addition of two number's=%d\n",a+b);
printf("Division of two number's=%d\n",a/b);
printf("Multiplication of two number's=%d\n",a*b);
return 0;
}