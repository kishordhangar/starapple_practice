
//5 Write a program for division of two numbers .

#include<stdio.h>

int main()
{
    int a=10;
    int b=3;
    int division =a/b;

    printf("\n\nDivision of two numbers=%d\n\n",division);
    return 0;
}