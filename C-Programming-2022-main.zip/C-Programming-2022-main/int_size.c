//8. Print size of int


#include<stdio.h>
int main()
{
 
int a;

printf("\n\n size of integer a= %d\n\n",sizeof(a));

    return 0;
}