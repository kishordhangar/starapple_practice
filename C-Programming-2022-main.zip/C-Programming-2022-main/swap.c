#include<stdio.h>
int main()
{

int a=10,b=20;

a=b;


printf("\nafter swaping integer a=%d\n",a);


    return 0;
}