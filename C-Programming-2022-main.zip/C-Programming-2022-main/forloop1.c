#include<stdio.h>
int main()
{


//local varibale declaration
int i=0;
for(i=1; i <=10; i=i+1)
{
printf("\n Hello world");
}
return 0;

}