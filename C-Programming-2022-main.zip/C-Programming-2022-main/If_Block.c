#include<stdio.h>

int main()
{
	// Variable Declarations

	// code

	// if condition FALSE - 0, TRUE -> Non-zero(+ve and -ve values)
	if (0)
	{ // if/else block started

		// True
		printf("\nIn if block");
	}
	else  // optional
	{
		// False
		printf("\nIn Else block");
	} // if/else block ended

	printf("\noutside of if/else block");

	return(0);
}
