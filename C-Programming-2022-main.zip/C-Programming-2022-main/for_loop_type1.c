#include<stdio.h>
int main()
{
    printf("\nFirst for loop\n");
    
    for(int i=1; i<=10; i++)
    {
        printf("\n%d",i);
    }
    
    return 0;
}