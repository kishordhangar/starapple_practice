#include<stdio.h>
int main()
{
    int i;

    for(i=1; i<=4; i++)
    {
        
        printf("*");
        
    }

    return 0;
}